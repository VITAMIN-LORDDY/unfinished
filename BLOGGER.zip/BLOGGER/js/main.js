$(document).ready(function(){

    $nav = $('.nav');
    $toogleCollapse = $('.$toogle-Collapse');

    // click event on toogle menu.......
    $toogleCollapse.click(function(){
        $nav.$toogleClass('collapse');
    })
});